create database hdfc;

use hdfc;

create table user
(
eid int,
name varchar(100),
sal int
);

desc user;
insert into user values(01,'Aman',30000), (02,'Ayush',40000);
select * from user where sal = 40000;

select * from user;

alter table user add country varchar(100);

user
update user set country = 'india';
select * from user;
alter table user add contact int;
update user set contact =1;

select * from user;
delete from user where eid = 01;
select * from user;
insert into user values(01,'Hello',50000,'america', 02);

select * from user;
select * from user where eid = 1;


-- alter table drop column
alter table user drop column country ;

-- alter table add column 
alter table user add country varchar(100) ;

-- drop table 
drop table user;


-- function : max, min, sum, avg, count 
select max(eid) from user;

select min(eid) from user;
select sum(eid) from user;
select count(eid) from user;
select avg(eid) from user;

select max(eid),min(eid), sum(eid) from user;

-- alias / show different name of column at runtime


select max(eid) as largenum,min(eid), sum(eid) from user;



-- sorting : order by
select * from user;
select * from user order by eid asc;

select * from user order by eid desc;

select * from user order by name asc;


--- group by : summarize the data

select name, count(name) from user group by name;







